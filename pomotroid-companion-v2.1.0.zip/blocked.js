// blocked.js - Logic for Focus Mode & 24/7 Adult Shield Blocked Screen

document.addEventListener('DOMContentLoaded', async () => {
  const urlDisplay = document.getElementById('blocked-url-display');
  const quoteDisplay = document.getElementById('motivational-quote');
  const btnBack = document.getElementById('btn-back');
  const statusBadgeText = document.getElementById('status-badge-text');
  const headline = document.querySelector('.headline');
  const subheadline = document.querySelector('.subheadline');
  const btnYoutube = document.getElementById('btn-youtube');
  const footerNote = document.querySelector('.footer-note');

  // 1. Parse query parameters
  const params = new URLSearchParams(window.location.search);
  const rawBlocked = params.get('blocked') || params.get('url') || document.referrer;
  const blockType = params.get('type') || '';
  let blockedUrl = rawBlocked;

  if (blockedUrl) {
    try {
      if (!blockedUrl.startsWith('http://') && !blockedUrl.startsWith('https://')) {
        blockedUrl = 'https://' + blockedUrl;
      }
      const parsed = new URL(blockedUrl);
      urlDisplay.textContent = parsed.hostname;
    } catch {
      urlDisplay.textContent = rawBlocked;
    }
  } else {
    urlDisplay.textContent = 'Restricted Domain';
  }

  // 2. Curated motivational quotes
  const focusQuotes = [
    '"Focus is a muscle. Every time you resist a distraction, you make it stronger."',
    '"Deep work is the ability to focus without distraction on a cognitively demanding task." — Cal Newport',
    '"You don’t need more time, you need more focus."',
    '"The successful warrior is the average man, with laser-like focus." — Bruce Lee',
    '"It is during our darkest moments that we must focus to see the light." — Aristotle',
    '"Action expresses priorities." — Mahatma Gandhi',
    '"Do one thing at a time, and do it with all your heart."'
  ];

  const adultQuotes = [
    '"Self-discipline is the master key to greatness."',
    '"Rule your mind or it will rule you." — Horace',
    '"The first and best victory is to conquer self." — Plato',
    '"Your future is created by what you do today, not tomorrow."',
    '"Freedom is not the absence of discipline; it is the result of it."'
  ];

  // 3. Handle Back button
  btnBack.addEventListener('click', () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.close();
    }
  });

  // 4. Handle Manage Sites (Dashboard) button
  const btnDashboard = document.getElementById('btn-dashboard');
  if (btnDashboard) {
    btnDashboard.addEventListener('click', () => {
      if (window.chrome && chrome.tabs && chrome.runtime && chrome.runtime.getURL) {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
      } else {
        window.location.href = 'dashboard/dashboard.html';
      }
    });
  }

  // 5. Special Treatment for 24/7 Adult Shield
  const isAdult = blockType === 'adult' || [
    'pornhub', 'xvideos', 'xnxx', 'xhamster', 'redtube', 'youporn',
    'chaturbate', 'onlyfans', 'stripchat', 'livejasmin', 'cam4',
    'bongacams', 'eporner', 'spankbang', 'tube8', 'beeg', 'kemono',
    'coomer', 'brazzers', 'bangbros', 'faphouse', 'erome', 'rule34',
    'nhentai', 'hanime', 'e-hentai', 'gelbooru'
  ].some(k => (rawBlocked || '').toLowerCase().includes(k));

  if (isAdult) {
    if (statusBadgeText) statusBadgeText.textContent = '24/7 ADULT SHIELD ACTIVE';
    if (headline) headline.textContent = 'Restricted Content Blocked';
    if (subheadline) {
      subheadline.textContent = 'Access to this website is blocked 24/7 by Pomotroid Shield to protect your digital well-being and keep your environment clean.';
    }
    if (quoteDisplay) {
      quoteDisplay.textContent = adultQuotes[Math.floor(Math.random() * adultQuotes.length)];
    }
    if (btnYoutube) {
      btnYoutube.style.display = 'none';
    }
    if (footerNote) {
      footerNote.textContent = 'Protected 24/7 by Pomotroid Shield. Adult domains remain restricted at all times.';
    }
    return; // Never auto-redirect back to an adult site
  }

  // 6. Focus Mode Blocked Screen
  quoteDisplay.textContent = focusQuotes[Math.floor(Math.random() * focusQuotes.length)];

  function updateFromState(state) {
    if (!state) return;
    if (state.round_type === 'work' && state.is_running) {
      statusBadgeText.textContent = 'POMODORO FOCUS ROUND ACTIVE';
    } else if (state.round_type === 'short-break') {
      statusBadgeText.textContent = 'ROUND: SHORT BREAK';
    } else if (state.round_type === 'long-break') {
      statusBadgeText.textContent = 'ROUND: LONG BREAK';
    } else {
      statusBadgeText.textContent = 'ROUND: IDLE';
    }

    // If focus mode ends or pauses, automatically redirect back to the work site!
    if (blockedUrl && (!state.is_running || state.round_type !== 'work')) {
      console.log(`[Pomotroid] Focus round ended — navigating back to ${blockedUrl}`);
      setTimeout(() => {
        window.location.href = blockedUrl;
      }, 400);
    }
  }

  if (window.chrome && chrome.storage && chrome.storage.local) {
    const data = await chrome.storage.local.get(['timerState', 'customMusicUrl']);
    if (data.timerState) {
      updateFromState(data.timerState);
    }
    if (data.customMusicUrl && btnYoutube) {
      btnYoutube.href = data.customMusicUrl;
    }

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.timerState) {
        updateFromState(changes.timerState.newValue);
      }
    });
  }
});
