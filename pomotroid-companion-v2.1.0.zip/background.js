// Pomotroid Companion - Chrome Background Service Worker (Manifest V3)
// Connects to Pomotroid Shield via local WebSocket (ws://pomotroid.shield:1314/ws or 127.0.0.1).
// Provides live badge countdown, popup timer sync, and declarative site blocking.

const WS_PORT = 1314;
const WS_URL = `ws://127.0.0.1:${WS_PORT}/ws`;
const RECONNECT_ALARM = 'pomotroid_ws_reconnect';

const DEFAULT_BLOCKED_DOMAINS = [
  'twitter.com', 'x.com', 'facebook.com', 'instagram.com',
  'reddit.com', 'tiktok.com', 'linkedin.com', 'netflix.com',
  'twitch.tv', 'threads.net', 'pinterest.com'
];

let socket = null;
let isConnecting = false;

let timerState = {
  connected: false,
  round_type: 'idle',
  is_running: false,
  is_paused: false,
  elapsed_secs: 0,
  total_secs: 1500,
  work_round_number: 1,
  work_rounds_total: 4
};

// ============================================================================
// Initialization & Storage
// ============================================================================

chrome.runtime.onInstalled.addListener(async () => {
  console.log('[Pomotroid Companion] Extension installed');
  const stored = await chrome.storage.local.get(['blocked_domains', 'blockedDomains', 'block_enabled']);
  const domains = stored.blockedDomains || stored.blocked_domains || DEFAULT_BLOCKED_DOMAINS;
  await chrome.storage.local.set({
    blocked_domains: domains,
    blockedDomains: domains,
    block_enabled: stored.block_enabled !== false
  });
  connectWebSocket();
});

chrome.runtime.onStartup.addListener(() => {
  connectWebSocket();
});

// Periodic keepalive / reconnect alarm
chrome.alarms.create(RECONNECT_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === RECONNECT_ALARM) {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      connectWebSocket();
    }
  }
});

// React to user modifying blocked sites in dashboard/popup
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.blocked_domains || changes.blockedDomains || changes.block_enabled) {
      syncDeclarativeRules();
    }
  }
});

// ============================================================================
// WebSocket Connection to Pomotroid Desktop App
// ============================================================================

function connectWebSocket() {
  if (isConnecting || (socket && socket.readyState === WebSocket.OPEN)) {
    return;
  }

  isConnecting = true;
  console.log('[Pomotroid Companion] Connecting to', WS_URL);

  try {
    socket = new WebSocket(WS_URL);

    socket.onopen = () => {
      console.log('[Pomotroid Companion] Connected to Pomotroid Desktop App!');
      isConnecting = false;
      timerState.connected = true;
      socket.send(JSON.stringify({ type: 'getState' }));
      updateStorageAndUI();
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        handleServerMessage(data);
      } catch (e) {
        console.error('[Pomotroid Companion] Error parsing message:', e);
      }
    };

    socket.onclose = () => {
      console.log('[Pomotroid Companion] WebSocket disconnected');
      isConnecting = false;
      socket = null;
      timerState.connected = false;
      updateStorageAndUI();
    };

    socket.onerror = (err) => {
      console.warn('[Pomotroid Companion] WebSocket error:', err);
      isConnecting = false;
    };
  } catch (err) {
    console.warn('[Pomotroid Companion] Failed to create WebSocket:', err);
    isConnecting = false;
  }
}

// ============================================================================
// Server Message Processing
// ============================================================================

function handleServerMessage(data) {
  const type = data.type;
  const payload = data.payload;

  switch (type) {
    case 'state':
    case 'roundChange':
      if (payload) {
        timerState.round_type = payload.round_type || 'work';
        timerState.elapsed_secs = payload.elapsed_secs ?? 0;
        timerState.total_secs = payload.total_secs || 1500;
        timerState.is_running = Boolean(payload.is_running);
        timerState.is_paused = Boolean(payload.is_paused);
        timerState.work_round_number = payload.work_round_number || 1;
        timerState.work_rounds_total = payload.work_rounds_total || 4;
      }
      break;

    case 'started':
      timerState.is_running = true;
      timerState.is_paused = false;
      if (payload?.total_secs) timerState.total_secs = payload.total_secs;
      break;

    case 'tick':
      if (payload) {
        timerState.elapsed_secs = payload.elapsed_secs;
        timerState.total_secs = payload.total_secs;
        timerState.is_running = true;
        timerState.is_paused = false;
      }
      break;

    case 'paused':
      timerState.is_running = false;
      timerState.is_paused = true;
      if (payload?.elapsed_secs !== undefined) timerState.elapsed_secs = payload.elapsed_secs;
      break;

    case 'resumed':
      timerState.is_running = true;
      timerState.is_paused = false;
      if (payload?.elapsed_secs !== undefined) timerState.elapsed_secs = payload.elapsed_secs;
      break;

    case 'reset':
      timerState.is_running = false;
      timerState.is_paused = false;
      timerState.elapsed_secs = 0;
      break;
  }

  updateStorageAndUI();
}

// ============================================================================
// UI Updates & Declarative Net Request Blocking
// ============================================================================

async function updateStorageAndUI() {
  await chrome.storage.local.set({ timerState });

  // Update extension toolbar badge
  if (!timerState.connected) {
    chrome.action.setBadgeText({ text: '' });
  } else if (timerState.round_type === 'work' && timerState.is_running) {
    const remSecs = Math.max(0, timerState.total_secs - timerState.elapsed_secs);
    const remMins = Math.ceil(remSecs / 60);
    chrome.action.setBadgeText({ text: `${remMins}m` });
    chrome.action.setBadgeBackgroundColor({ color: '#FF4E4D' }); // Pomotroid Red
  } else if (timerState.round_type === 'short-break' || timerState.round_type === 'long-break') {
    chrome.action.setBadgeText({ text: 'BRK' });
    chrome.action.setBadgeBackgroundColor({ color: '#05EC8C' }); // Pomotroid Green
  } else if (timerState.is_paused) {
    chrome.action.setBadgeText({ text: '||' });
    chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' }); // Amber
  } else {
    chrome.action.setBadgeText({ text: '' });
  }

  // Manage in-browser blocking
  await syncDeclarativeRules();
}

async function syncDeclarativeRules() {
  const stored = await chrome.storage.local.get(['blocked_domains', 'blockedDomains', 'block_enabled']);
  const blockedDomains = stored.blockedDomains || stored.blocked_domains || DEFAULT_BLOCKED_DOMAINS;
  const blockEnabled = stored.block_enabled !== false;

  const shouldBlock =
    blockEnabled &&
    timerState.connected &&
    timerState.round_type === 'work' &&
    timerState.is_running;

  // Clear existing dynamic rules
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const ruleIdsToRemove = existingRules.map((r) => r.id);

  if (!shouldBlock || blockedDomains.length === 0) {
    if (ruleIdsToRemove.length > 0) {
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIdsToRemove
      });
      console.log('[Pomotroid Companion] Cleared browser block rules');
    }
    return;
  }

  const blockedHtmlUrl = chrome.runtime.getURL('blocked.html');
  const newRules = blockedDomains.map((domain, index) => {
    const clean = domain.trim().toLowerCase();
    return {
      id: index + 100,
      priority: 1,
      action: {
        type: 'redirect',
        redirect: {
          url: `${blockedHtmlUrl}?blocked=${encodeURIComponent(clean)}&type=focus`
        }
      },
      condition: {
        urlFilter: `||${clean}^`,
        resourceTypes: ['main_frame']
      }
    };
  });

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: ruleIdsToRemove,
    addRules: newRules
  });

  console.log(`[Pomotroid Companion] Activated ${newRules.length} block rules for focus round`);
}

// ============================================================================
// Extension IPC (Popup, Content Script & Options Communication)
// ============================================================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getTimerState') {
    sendResponse({ state: timerState });
    return false;
  }

  if (message.action === 'reconnect') {
    connectWebSocket();
    sendResponse({ status: 'reconnecting' });
    return false;
  }

  if (message.action === 'updateBlockedDomains') {
    syncDeclarativeRules().then(() => sendResponse({ status: 'ok' }));
    return true;
  }

  return false;
});
