// dashboard.js - Logic for Pomotroid Bridge Control & Management Hub

const DEFAULT_BLOCKED_DOMAINS = [
  'twitter.com',
  'x.com',
  'facebook.com',
  'instagram.com',
  'tiktok.com',
  'reddit.com',
  'snapchat.com',
  'pinterest.com',
  'threads.net',
  'linkedin.com',
  'tumblr.com',
  'bsky.app'
];

const DEFAULT_WHITELISTED_DOMAINS = [
  'youtube.com',
  'music.youtube.com',
  'github.com',
  'stackoverflow.com',
  'google.com'
];

document.addEventListener('DOMContentLoaded', async () => {
  // Header Elements
  const dotPomotroid = document.getElementById('dot-pomotroid');
  const textPomotroid = document.getElementById('text-pomotroid');
  const indicatorMode = document.getElementById('indicator-mode');
  const btnQuickSync = document.getElementById('btn-quick-sync');

  // Global macOS Shield Elements
  const dotGlobalStatus = document.getElementById('dot-global-status');
  const labelGlobalStatus = document.getElementById('label-global-status');
  const bannerGlobalSetup = document.getElementById('banner-global-setup');
  const btnSyncGlobal = document.getElementById('btn-sync-global');
  const btnCopySetupCmd = document.getElementById('btn-copy-setup-cmd');
  const codeSetupCmd = document.getElementById('code-setup-cmd');
  const pillGlobalFocusCount = document.getElementById('pill-global-focus-count');

  // Adult Blocker Elements
  const chkAdultBlock = document.getElementById('chk-adult-block');
  const sliderAdultBlock = document.getElementById('slider-adult-block');
  const knobAdultBlock = document.getElementById('knob-adult-block');
  const adultFilterLabel = document.getElementById('adult-filter-label');

  // Blocklist Elements
  const blockCount = document.getElementById('block-count');
  const inputNewBlock = document.getElementById('input-new-block');
  const btnAddBlock = document.getElementById('btn-add-block');
  const blocklistContainer = document.getElementById('blocklist-container');
  const btnResetBlock = document.getElementById('btn-reset-blocklist');
  const btnClearBlock = document.getElementById('btn-clear-blocklist');

  // Whitelist Elements
  const whiteCount = document.getElementById('white-count');
  const inputNewWhite = document.getElementById('input-new-white');
  const btnAddWhite = document.getElementById('btn-add-white');
  const whitelistContainer = document.getElementById('whitelist-container');
  const btnResetWhite = document.getElementById('btn-reset-whitelist');
  const btnClearWhite = document.getElementById('btn-clear-whitelist');

  // Notification Toast
  const toastBar = document.getElementById('toast-bar');

  function showToast(msg, duration = 3000) {
    if (!toastBar) return;
    toastBar.textContent = msg;
    toastBar.classList.add('show');
    setTimeout(() => {
      toastBar.classList.remove('show');
    }, duration);
  }

  function cleanDomain(input) {
    if (!input) return '';
    let d = input.trim().toLowerCase();
    d = d.replace(/^https?:\/\//, '');
    d = d.replace(/\/.*$/, '');
    d = d.replace(/^www\./, '');
    return d;
  }

  // ==========================================================================
  // Storage & State Sync
  // ==========================================================================

  let currentBlocklist = [];
  let currentWhitelist = [];

  async function loadData() {
    const data = await chrome.storage.local.get([
      'blockedDomains',
      'whitelistedDomains',
      'blockAdultContent',
      'isConnected',
      'currentRoundType',
      'isRunning'
    ]);

    currentBlocklist = data.blockedDomains || DEFAULT_BLOCKED_DOMAINS;
    currentWhitelist = data.whitelistedDomains || DEFAULT_WHITELISTED_DOMAINS;

    if (!data.blockedDomains) {
      await chrome.storage.local.set({ blockedDomains: currentBlocklist });
    }
    if (!data.whitelistedDomains) {
      await chrome.storage.local.set({ whitelistedDomains: currentWhitelist });
    }

    const isAdultActive = data.blockAdultContent !== false;
    if (chkAdultBlock) chkAdultBlock.checked = isAdultActive;
    updateAdultBlockToggleUI(isAdultActive);

    renderBlocklist();
    renderWhitelist();
    renderState(data);
  }

  function renderState(data) {
    const isConnected = !!data.isConnected;
    const roundType = data.currentRoundType || 'idle';
    const isRunning = !!data.isRunning;

    // Header connection
    if (isConnected) {
      if (dotPomotroid) dotPomotroid.className = 'status-dot connected';
      if (textPomotroid) textPomotroid.textContent = 'Connected to Pomotroid (Port 1314)';
    } else {
      if (dotPomotroid) dotPomotroid.className = 'status-dot disconnected';
      if (textPomotroid) textPomotroid.textContent = 'Pomotroid is offline (Port 1314)';
    }

    // Header Mode indicator
    if (!indicatorMode) return;
    if (!isConnected) {
      indicatorMode.className = 'mode-indicator mode-idle';
      indicatorMode.textContent = 'OFFLINE';
    } else if (roundType === 'work') {
      indicatorMode.className = isRunning ? 'mode-indicator mode-focus' : 'mode-indicator mode-idle';
      indicatorMode.textContent = isRunning ? 'FOCUS ROUND' : 'FOCUS PAUSED';
    } else if (roundType === 'short-break' || roundType === 'long-break') {
      indicatorMode.className = 'mode-indicator mode-break';
      indicatorMode.textContent = roundType === 'long-break' ? 'LONG BREAK' : 'SHORT BREAK';
    } else {
      indicatorMode.className = 'mode-indicator mode-idle';
      indicatorMode.textContent = 'IDLE';
    }

    // Global macOS Shield Status
    renderGlobalBlockStatus(data.globalBlockStatus || {}, roundType, isRunning, isConnected);
  }

  function renderGlobalBlockStatus(status = {}, roundType = 'idle', isRunning = false, isConnected = false) {
    if (!dotGlobalStatus || !labelGlobalStatus) return;

    const isWritable = !!status.isWritable;
    const focusBlocked = !!status.focusBlocked;

    if (!isWritable) {
      dotGlobalStatus.className = 'status-dot disconnected';
      labelGlobalStatus.textContent = 'Setup Required (Permissions Needed)';
      if (bannerGlobalSetup) bannerGlobalSetup.style.display = 'block';
      if (pillGlobalFocusCount) pillGlobalFocusCount.style.display = 'none';
      return;
    }

    if (bannerGlobalSetup) bannerGlobalSetup.style.display = 'none';

    if (focusBlocked) {
      dotGlobalStatus.className = 'status-dot connected';
      labelGlobalStatus.textContent = 'System-Wide Active (Protected across all macOS Browsers)';
      if (pillGlobalFocusCount) {
        pillGlobalFocusCount.style.display = 'inline-block';
        pillGlobalFocusCount.textContent = `${status.focusCount || currentBlocklist.length} Focus Sites`;
      }
    } else {
      if (pillGlobalFocusCount) pillGlobalFocusCount.style.display = 'none';

      if (isConnected && roundType === 'work' && !isRunning) {
        dotGlobalStatus.className = 'status-dot disconnected';
        dotGlobalStatus.style.backgroundColor = '#fbbf24';
        labelGlobalStatus.textContent = 'Focus Paused (OS Shield Lifted for Browsing)';
      } else if (isConnected && (roundType === 'short-break' || roundType === 'long-break')) {
        dotGlobalStatus.className = 'status-dot connected';
        labelGlobalStatus.textContent = 'Break Mode (Social Sites Unblocked on macOS)';
      } else {
        dotGlobalStatus.className = 'status-dot connected';
        labelGlobalStatus.textContent = 'Ready (Armed for next Focus round)';
      }
    }
  }

  // ==========================================================================
  // Render Lists
  // ==========================================================================

  function renderBlocklist() {
    if (!blocklistContainer) return;
    blocklistContainer.innerHTML = '';
    if (blockCount) blockCount.textContent = `${currentBlocklist.length} Site${currentBlocklist.length === 1 ? '' : 's'}`;

    if (currentBlocklist.length === 0) {
      blocklistContainer.innerHTML = '<div class="empty-list">No websites blocked. Click a suggestion or add a domain above.</div>';
      return;
    }

    currentBlocklist.forEach(domain => {
      const item = document.createElement('div');
      item.className = 'domain-row';
      item.innerHTML = `
        <div class="domain-info">
          <span class="domain-dot block-dot"></span>
          <span class="domain-name">${domain}</span>
        </div>
        <button class="btn-remove-domain" data-domain="${domain}" title="Remove ${domain}">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      `;
      blocklistContainer.appendChild(item);
    });

    blocklistContainer.querySelectorAll('.btn-remove-domain').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const dom = e.currentTarget.dataset.domain;
        await removeBlockedDomain(dom);
      });
    });
  }

  function renderWhitelist() {
    if (!whitelistContainer) return;
    whitelistContainer.innerHTML = '';
    if (whiteCount) whiteCount.textContent = `${currentWhitelist.length} Site${currentWhitelist.length === 1 ? '' : 's'}`;

    if (currentWhitelist.length === 0) {
      whitelistContainer.innerHTML = '<div class="empty-list">No safe sites configured. Click a suggestion or add a domain above.</div>';
      return;
    }

    currentWhitelist.forEach(domain => {
      const item = document.createElement('div');
      item.className = 'domain-row';
      item.innerHTML = `
        <div class="domain-info">
          <span class="domain-dot white-dot"></span>
          <span class="domain-name domain-name-safe">${domain}</span>
        </div>
        <button class="btn-remove-domain" data-domain="${domain}" title="Remove ${domain}">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      `;
      whitelistContainer.appendChild(item);
    });

    whitelistContainer.querySelectorAll('.btn-remove-domain').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const dom = e.currentTarget.dataset.domain;
        await removeWhitelistedDomain(dom);
      });
    });
  }

  // ==========================================================================
  // Domain List Actions
  // ==========================================================================

  async function addBlockedDomain(domain) {
    const clean = cleanDomain(domain);
    if (!clean) return;

    if (clean === 'youtube.com' || clean.endsWith('.youtube.com')) {
      showToast('YouTube cannot be blocked (whitelisted for focus audio).');
      return;
    }

    if (currentBlocklist.includes(clean)) {
      showToast(`${clean} is already blocked.`);
      return;
    }

    currentBlocklist.push(clean);
    await chrome.storage.local.set({ blockedDomains: currentBlocklist });
    renderBlocklist();
    showToast(`Added ${clean} to blocked sites.`);
    if (inputNewBlock) inputNewBlock.value = '';
  }

  async function removeBlockedDomain(domain) {
    currentBlocklist = currentBlocklist.filter(d => d !== domain);
    await chrome.storage.local.set({ blockedDomains: currentBlocklist });
    renderBlocklist();
    showToast(`Removed ${domain} from blocked sites.`);
  }

  async function addWhitelistedDomain(domain) {
    const clean = cleanDomain(domain);
    if (!clean) return;

    if (currentWhitelist.includes(clean)) {
      showToast(`${clean} is already whitelisted.`);
      return;
    }

    currentWhitelist.push(clean);
    await chrome.storage.local.set({ whitelistedDomains: currentWhitelist });
    renderWhitelist();
    showToast(`Added ${clean} to safe sites.`);
    if (inputNewWhite) inputNewWhite.value = '';
  }

  async function removeWhitelistedDomain(domain) {
    currentWhitelist = currentWhitelist.filter(d => d !== domain);
    await chrome.storage.local.set({ whitelistedDomains: currentWhitelist });
    renderWhitelist();
    showToast(`Removed ${domain} from safe sites.`);
  }

  // ==========================================================================
  // Event Listeners
  // ==========================================================================

  if (btnAddBlock && inputNewBlock) {
    btnAddBlock.addEventListener('click', () => addBlockedDomain(inputNewBlock.value));
    inputNewBlock.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') addBlockedDomain(inputNewBlock.value);
    });
  }

  document.querySelectorAll('.chip-btn').forEach(btn => {
    btn.addEventListener('click', () => addBlockedDomain(btn.dataset.domain));
  });

  if (btnResetBlock) {
    btnResetBlock.addEventListener('click', async () => {
      currentBlocklist = [...DEFAULT_BLOCKED_DOMAINS];
      await chrome.storage.local.set({ blockedDomains: currentBlocklist });
      renderBlocklist();
      showToast('Blocklist reset to default social sites.');
    });
  }

  if (btnClearBlock) {
    btnClearBlock.addEventListener('click', async () => {
      currentBlocklist = [];
      await chrome.storage.local.set({ blockedDomains: currentBlocklist });
      renderBlocklist();
      showToast('Blocklist cleared.');
    });
  }

  if (btnAddWhite && inputNewWhite) {
    btnAddWhite.addEventListener('click', () => addWhitelistedDomain(inputNewWhite.value));
    inputNewWhite.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') addWhitelistedDomain(inputNewWhite.value);
    });
  }

  document.querySelectorAll('.chip-white-btn').forEach(btn => {
    btn.addEventListener('click', () => addWhitelistedDomain(btn.dataset.domain));
  });

  if (btnResetWhite) {
    btnResetWhite.addEventListener('click', async () => {
      currentWhitelist = [...DEFAULT_WHITELISTED_DOMAINS];
      await chrome.storage.local.set({ whitelistedDomains: currentWhitelist });
      renderWhitelist();
      showToast('Whitelist reset to default productivity sites.');
    });
  }

  if (btnClearWhite) {
    btnClearWhite.addEventListener('click', async () => {
      currentWhitelist = [];
      await chrome.storage.local.set({ whitelistedDomains: currentWhitelist });
      renderWhitelist();
      showToast('Whitelist cleared.');
    });
  }

  // 24/7 Adult Shield Switch
  function updateAdultBlockToggleUI(enabled) {
    if (sliderAdultBlock) sliderAdultBlock.style.backgroundColor = enabled ? '#10b981' : '#475569';
    if (knobAdultBlock) knobAdultBlock.style.left = enabled ? '22px' : '3px';
    if (adultFilterLabel) {
      adultFilterLabel.textContent = enabled ? 'Active 24/7' : 'Disabled';
      adultFilterLabel.style.color = enabled ? '#34d399' : '#94a3b8';
    }
  }

  if (chkAdultBlock) {
    chkAdultBlock.addEventListener('change', async () => {
      const enabled = chkAdultBlock.checked;
      await chrome.storage.local.set({ blockAdultContent: enabled });
      updateAdultBlockToggleUI(enabled);
      showToast(enabled ? '24/7 Adult Content Filter active.' : 'Adult Content Filter disabled.');
    });
  }

  // Quick Sync in Header
  if (btnQuickSync) {
    btnQuickSync.addEventListener('click', async () => {
      showToast('Syncing with Pomotroid...');
      await chrome.runtime.sendMessage({ action: 'reconnect' });
    });
  }

  // Global macOS Shield Actions
  if (btnSyncGlobal) {
    btnSyncGlobal.addEventListener('click', async () => {
      showToast('Syncing Global macOS Shield (/etc/hosts)...');
      try {
        await chrome.runtime.sendMessage({ action: 'syncGlobalBlock' });
        const res = await chrome.runtime.sendMessage({ action: 'getGlobalBlockStatus' });
        if (res && res.data) {
          const st = res.data;
          const { currentRoundType = 'idle', isRunning = false, isConnected = false } = await chrome.storage.local.get(['currentRoundType', 'isRunning', 'isConnected']);
          renderGlobalBlockStatus(st, currentRoundType, isRunning, isConnected);
          if (st.isWritable) {
            showToast('✓ Global macOS Shield successfully synced across all browsers!');
          } else {
            showToast('Permission needed: run the command in Terminal below.');
          }
        }
      } catch (err) {
        showToast('Error syncing global shield: ' + (err.message || err));
      }
    });
  }

  if (btnCopySetupCmd && codeSetupCmd) {
    btnCopySetupCmd.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(codeSetupCmd.textContent.trim());
        showToast('✓ Command copied! Paste into Terminal and press Enter.');
      } catch (_) {
        showToast('Copy command: ' + codeSetupCmd.textContent.trim());
      }
    });
  }

  // ==========================================================================
  // Real-time Storage Listener
  // ==========================================================================

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' || areaName === 'sync') {
      if (changes.blockAdultContent && chkAdultBlock) {
        const isNow = changes.blockAdultContent.newValue !== false;
        chkAdultBlock.checked = isNow;
        updateAdultBlockToggleUI(isNow);
      }
      if (changes.blockedDomains) {
        currentBlocklist = changes.blockedDomains.newValue || [];
        renderBlocklist();
      }
      if (changes.whitelistedDomains) {
        currentWhitelist = changes.whitelistedDomains.newValue || [];
        renderWhitelist();
      }
      chrome.storage.local.get(null).then(renderState);
    }
  });

  // Initial load
  await loadData();
});
