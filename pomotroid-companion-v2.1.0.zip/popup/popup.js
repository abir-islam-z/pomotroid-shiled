// popup.js - Logic for Pomotroid Companion Extension

document.addEventListener('DOMContentLoaded', async () => {
  const connDot = document.getElementById('conn-dot');
  const connLabel = document.getElementById('conn-label');
  const connPill = document.getElementById('conn-pill');
  
  const stateCard = document.getElementById('state-card');
  const modeTag = document.getElementById('mode-tag');
  const roundCount = document.getElementById('round-count');
  const timeVal = document.getElementById('time-val');
  const timeSub = document.getElementById('time-sub');
  
  const blockState = document.getElementById('block-state');
  const syncState = document.getElementById('sync-state');
  const chkSiteBlock = document.getElementById('chk-site-block');
  
  const btnOpenHub = document.getElementById('btn-open-hub');
  const btnDashboard = document.getElementById('btn-dashboard');
  const linkDashboard = document.getElementById('link-dashboard');
  const btnReconnect = document.getElementById('btn-reconnect');
  const popupToast = document.getElementById('popup-toast');

  function showToast(msg, duration = 2000) {
    popupToast.textContent = msg;
    popupToast.style.display = 'block';
    setTimeout(() => {
      popupToast.style.display = 'none';
    }, duration);
  }

  function formatTime(secs) {
    if (typeof secs !== 'number' || isNaN(secs) || secs < 0) return '00:00';
    const mins = Math.floor(secs / 60);
    const remainder = Math.floor(secs % 60);
    return `${String(mins).padStart(2, '0')}:${String(remainder).padStart(2, '0')}`;
  }

  function renderState(timerState) {
    if (!timerState || !timerState.connected) {
      connDot.style.background = '#94a3b8';
      connLabel.textContent = 'Offline';
      timeSub.textContent = 'Open Pomotroid app to sync';
      modeTag.textContent = 'DISCONNECTED';
      modeTag.style.background = 'rgba(148, 163, 184, 0.15)';
      modeTag.style.color = '#94a3b8';
      syncState.textContent = 'Waiting';
      return;
    }

    connDot.style.background = '#10b981'; // Green
    connLabel.textContent = 'Connected';
    syncState.textContent = 'Live';

    const rt = timerState.round_type;
    const isRunning = timerState.is_running;
    const rem = Math.max(0, timerState.total_secs - timerState.elapsed_secs);
    timeVal.textContent = formatTime(rem);

    roundCount.textContent = `Round ${timerState.work_round_number || 1} of ${timerState.work_rounds_total || 4}`;

    if (rt === 'work') {
      modeTag.textContent = isRunning ? 'FOCUS ROUND' : 'FOCUS (PAUSED)';
      modeTag.style.background = 'rgba(255, 78, 77, 0.15)';
      modeTag.style.color = '#FF4E4D';
      timeSub.textContent = isRunning ? 'Stay in the flow' : 'Paused';
      blockState.textContent = isRunning ? 'Active' : 'Standby';
    } else if (rt === 'short-break') {
      modeTag.textContent = 'SHORT BREAK';
      modeTag.style.background = 'rgba(5, 236, 140, 0.15)';
      modeTag.style.color = '#05EC8C';
      timeSub.textContent = 'Step away and rest your eyes';
      blockState.textContent = 'Unlocked';
    } else if (rt === 'long-break') {
      modeTag.textContent = 'LONG BREAK';
      modeTag.style.background = 'rgba(11, 189, 219, 0.15)';
      modeTag.style.color = '#0BBDDB';
      timeSub.textContent = 'Recharge your mind';
      blockState.textContent = 'Unlocked';
    } else {
      modeTag.textContent = 'IDLE';
      modeTag.style.background = 'rgba(255, 255, 255, 0.1)';
      modeTag.style.color = '#e2e8f0';
      timeSub.textContent = 'Ready to focus';
      blockState.textContent = 'Standby';
    }
  }

  // Load initial settings
  const stored = await chrome.storage.local.get(['timerState', 'block_enabled']);
  if (stored.block_enabled !== undefined) {
    chkSiteBlock.checked = stored.block_enabled;
  }
  renderState(stored.timerState);

  // Toggle tab blocking
  chkSiteBlock.addEventListener('change', async () => {
    const enabled = chkSiteBlock.checked;
    await chrome.storage.local.set({ block_enabled: enabled });
    chrome.runtime.sendMessage({ action: 'updateBlockedDomains' });
    showToast(enabled ? 'Focus blocking enabled' : 'Focus blocking paused');
  });

  // Reconnect / Sync button
  btnReconnect.addEventListener('click', () => {
    btnReconnect.classList.add('rotating');
    chrome.runtime.sendMessage({ action: 'reconnect' });
    showToast('Syncing with Pomotroid...');
    setTimeout(() => {
      btnReconnect.classList.remove('rotating');
    }, 1000);
  });

  // Dashboard buttons
  function openDashboard() {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
  }

  btnOpenHub.addEventListener('click', openDashboard);
  btnDashboard.addEventListener('click', openDashboard);
  linkDashboard.addEventListener('click', openDashboard);

  // Storage listener for real-time reactive UI
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.timerState) {
      renderState(changes.timerState.newValue);
    }
  });
});
