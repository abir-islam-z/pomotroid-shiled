// content-detector.js - Real-time In-Page Metadata & RTA Rating Classifier
// Injected at document_start to block all adult-rated sites implicitly via HTML <meta> tags.

(function () {
  'use strict';

  const host = window.location.hostname.toLowerCase();
  const SAFE_DOMAINS = [
    'google.com', 'youtube.com', 'github.com', 'stackoverflow.com',
    'wikipedia.org', 'apple.com', 'microsoft.com', 'linkedin.com',
    'amazon.com', 'mozilla.org', 'w3schools.com', 'mdn.dev', '127.0.0.1', 'localhost'
  ];

  if (SAFE_DOMAINS.some(d => host === d || host.endsWith('.' + d))) {
    return;
  }

  // 1. Fast URL Keyword Heuristics
  const fullUrl = window.location.href.toLowerCase();
  const ADULT_URL_PATTERNS = [
    'porn', 'xxx', 'hentai', 'cum', 'milf', 'blowjob', 'anal',
    'dildo', 'fetish', 'creampie', 'boobs', 'tits', 'squirt',
    'fap', 'shemale', 'nude', 'naked', 'erotic', 'bdsm', 'threesome',
    'stripchat', 'chaturbate', 'camsoda', 'onlyfans', 'brazzers',
    'bangbros', 'faphouse', 'erome', 'rule34', 'nhentai', 'tube8',
    'eporner', 'spankbang', 'redtube', 'youporn', 'xvideos', 'xnxx', 'cumlouder'
  ];

  for (const pat of ADULT_URL_PATTERNS) {
    if (fullUrl.includes(pat)) {
      triggerAdultBlock(`URL pattern: ${pat}`);
      return;
    }
  }

  // 2. Comprehensive HTML Metadata & Rating Inspection
  function inspectMetadata() {
    // A. RTA (Restricted to Adults) & Standard Content Rating Meta Tags
    const ratingMeta = document.querySelector('meta[name*="rating" i], meta[property*="rating" i], meta[http-equiv*="rating" i], meta[name*="rta" i], meta[http-equiv*="pics-label" i]');
    if (ratingMeta) {
      const content = (ratingMeta.getAttribute('content') || '').toLowerCase();
      if (content.includes('rta') || content.includes('adult') || content.includes('mature') || content.includes('restricted') || content.includes('18')) {
        triggerAdultBlock(`Adult Rating Meta Tag: ${content}`);
        return true;
      }
    }

    // B. Classification / Category Meta Tags
    const classMeta = document.querySelector('meta[name*="classification" i], meta[name*="category" i]');
    if (classMeta) {
      const content = (classMeta.getAttribute('content') || '').toLowerCase();
      if (content.includes('adult') || content.includes('porn') || content.includes('erotic') || content.includes('xxx')) {
        triggerAdultBlock(`Classification: ${content}`);
        return true;
      }
    }

    // C. OpenGraph Adult Labels
    const ogType = document.querySelector('meta[property="og:type" i], meta[name="description" i]');
    if (ogType) {
      const content = (ogType.getAttribute('content') || '').toLowerCase();
      if (content.includes('free porn') || content.includes('xxx sex') || content.includes('adult video') || content.includes('porn videos')) {
        triggerAdultBlock(`Meta description adult tag`);
        return true;
      }
    }

    // D. Page Title High-Confidence Keywords
    const pageTitle = (document.title || '').toLowerCase();
    const adultTitleTokens = [
      'porn', 'xxx', 'cum', 'milf', 'hentai', 'sex video', 'free porn',
      'blowjob', 'hardcore porn', 'cam girl', 'xvideos', 'pornhub'
    ];

    for (const token of adultTitleTokens) {
      if (pageTitle.includes(token)) {
        triggerAdultBlock(`Title contains: ${token}`);
        return true;
      }
    }

    return false;
  }

  function triggerAdultBlock(reason) {
    try {
      window.stop();
      if (document.documentElement) {
        document.documentElement.style.display = 'none';
      }
      const targetUrl = 'http://127.0.0.1:1314/blocked?blocked=' + encodeURIComponent(window.location.href) + '&type=adult';
      window.location.replace(targetUrl);
    } catch (_) {}
  }

  // Inspect immediately at document_start
  if (inspectMetadata()) return;

  // Observe dynamically added meta tags
  const observer = new MutationObserver(() => {
    if (inspectMetadata()) observer.disconnect();
  });

  if (document.documentElement) {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  document.addEventListener('DOMContentLoaded', () => {
    observer.disconnect();
    inspectMetadata();
  }, { once: true });
})();
